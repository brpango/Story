<?php

$host = 'localhost';
$database = 'teammate';
$username = 'naotapi';
$password = 'S@cr@t1!';